# 1. 解压
mkdir qr-file-station && tar -xzf qr-file-station.tar.gz -C qr-file-station

# 2. 导入镜像
./qr-file-station.sh deploy

# 3. 启动 Web 服务
./qr-file-station.sh start

# 4. 转换文件为二维码
./qr-file-station.sh encode /path/to/files /path/to/output

# 5. 直接在 Linux 终端展示二维码
#    可传原始文件目录，也可传已生成的二维码图片目录
./qr-file-station.sh show /path/to/files
./qr-file-station.sh show /path/to/output

# 6. 停止服务
./qr-file-station.sh stop