#!/bin/bash
# ============================================
# 文件二维码转换站 - 一键部署脚本
# 纯 docker run 实现，无需 docker-compose
# ============================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

green() { echo -e "\033[32m$1\033[0m"; }
yellow() { echo -e "\033[33m$1\033[0m"; }
red() { echo -e "\033[31m$1\033[0m"; }

WEB_IMAGE="qr-file-station-web:latest"
ENCODER_IMAGE="qr-file-station-encoder:latest"
WEB_CONTAINER="qr-file-web"

# ---------- 部署（导入镜像） ----------
deploy() {
    if [ ! -f "$SCRIPT_DIR/images.tar" ]; then
        red "错误: 未找到 images.tar"
        exit 1
    fi

    green "正在导入 Docker 镜像..."
    docker load -i "$SCRIPT_DIR/images.tar"

    green "镜像导入完成！"
    echo ""
    docker images | grep qr-file-station || true
    echo ""
    green "接下来运行: $0 start"
}

# ---------- 启动服务 ----------
start() {
    # 如果已存在旧容器则先删除
    docker rm -f "$WEB_CONTAINER" >/dev/null 2>&1 || true

    green "正在启动 Web 服务..."
    docker run -d \
        --name "$WEB_CONTAINER" \
        --restart unless-stopped \
        -p 8080:80 \
        -p 8443:443 \
        "$WEB_IMAGE"

    # 获取本机 IP（兼容 Linux 和 macOS）
    LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    if [ -z "$LOCAL_IP" ]; then
        LOCAL_IP=$(ip route get 1 2>/dev/null | awk '{print $7; exit}')
    fi
    if [ -z "$LOCAL_IP" ]; then
        LOCAL_IP=$(ipconfig getifaddr en0 2>/dev/null)
    fi
    if [ -z "$LOCAL_IP" ]; then
        LOCAL_IP="<本机IP>"
    fi

    echo ""
    green "===================================="
    green "  服务已启动！"
    green "===================================="
    echo ""
    echo "  本机访问:  https://localhost:8443"
    echo "  局域网访问: https://$LOCAL_IP:8443"
    echo ""
    yellow "  iOS 首次访问会提示证书不受信任"
    yellow "  点击「显示详细信息」→「访问此网站」即可"
    echo ""
}

# ---------- 停止服务 ----------
stop() {
    green "正在停止服务..."
    docker rm -f "$WEB_CONTAINER" >/dev/null 2>&1 || true
    green "服务已停止"
}

# ---------- 转换文件为二维码 ----------
encode() {
    local input="${1:-}"
    local output="${2:-}"

    if [ -z "$input" ]; then
        red "用法: $0 encode <输入目录> [输出目录]"
        echo "  例: $0 encode /path/to/files /path/to/output"
        exit 1
    fi

    if [ -z "$output" ]; then
        output="$input/qr_output"
    fi

    mkdir -p "$output"

    green "正在转换文件为二维码..."
    green "  输入: $input"
    green "  输出: $output"

    # 优先使用本地可执行文件（无需 Docker）
    if [ -x "$SCRIPT_DIR/file_to_qr" ]; then
        green "  方式: 本地可执行文件"
        "$SCRIPT_DIR/file_to_qr" "$input" "$output"
    elif docker images 2>/dev/null | grep -q "$ENCODER_IMAGE"; then
        green "  方式: Docker 容器"
        docker run --rm \
            -v "$input:/data/input:ro" \
            -v "$output:/data/output" \
            "$ENCODER_IMAGE" \
            python file_to_qr.py /data/input /data/output
    else
        red "错误: 未找到 file_to_qr 可执行文件，也未导入 Docker 镜像"
        red "请先运行: $0 deploy"
        exit 1
    fi
}

# ---------- 在终端展示二维码 ----------
show() {
    local input="${1:-}"

    if [ -z "$input" ]; then
        red "用法: $0 show <输入目录或二维码图片目录>"
        echo "  例: $0 show /path/to/files"
        echo "  例: $0 show /path/to/qr_output"
        exit 1
    fi

    if [ ! -d "$input" ]; then
        red "错误: 目录不存在: $input"
        exit 1
    fi

    green "正在终端展示二维码..."
    green "  输入: $input"

    local browser_script="$SCRIPT_DIR/terminal_qr_browser.py"
    if [ ! -f "$browser_script" ] && [ -f "$SCRIPT_DIR/../terminal_qr_browser.py" ]; then
        browser_script="$SCRIPT_DIR/../terminal_qr_browser.py"
    fi

    if [ -f "$browser_script" ]; then
        if find "$input" -maxdepth 1 -type f -name "*.png" | grep -q .; then
            python3 "$browser_script" --image-dir "$input"
        else
            python3 "$browser_script" --input-dir "$input"
        fi
    else
        red "错误: 未找到 terminal_qr_browser.py"
        exit 1
    fi
}

# ---------- 帮助 ----------
help() {
    echo ""
    echo "文件二维码转换站 - 管理脚本（纯 Docker，无需 docker-compose）"
    echo ""
    echo "用法: $0 <命令> [参数]"
    echo ""
    echo "命令:"
    echo "  deploy           导入 Docker 镜像（首次部署时执行）"
    echo "  start            启动 Web 扫描服务"
    echo "  stop             停止服务"
    echo "  encode <输入> [输出]  将文件转换为二维码图片"
    echo "  show <输入>      在终端展示文件二维码或已生成的 PNG 二维码"
    echo "  help             显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 deploy"
    echo "  $0 start"
    echo "  $0 encode ./my_files ./qr_codes"
    echo "  $0 show ./my_files"
    echo "  $0 show ./qr_codes"
    echo "  $0 stop"
    echo ""
}

# ---------- 主入口 ----------
case "${1:-}" in
    deploy)  deploy ;;
    start)   start ;;
    stop)    stop ;;
    encode)  encode "$2" "$3" ;;
    show)    show "$2" ;;
    help|--help|-h) help ;;
    *)
        red "未知命令: ${1:-}"
        help
        exit 1
        ;;
esac
